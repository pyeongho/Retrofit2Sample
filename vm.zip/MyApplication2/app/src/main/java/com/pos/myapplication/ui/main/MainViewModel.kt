package com.pos.myapplication.ui.main

import android.view.View
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {



    private val _hello= MutableLiveData<String>().apply {
        value = "hello ViewModel"
    }
    val hello: LiveData<String> get() = _hello

    private val _clickedButton= MutableLiveData<View>()
    val clickedButton: LiveData<View> get() = _clickedButton

    fun onClickedButton(v : View){
        _clickedButton.value = v
    }

    fun changeText(s: String) {
        _hello.value = s
    }

}
